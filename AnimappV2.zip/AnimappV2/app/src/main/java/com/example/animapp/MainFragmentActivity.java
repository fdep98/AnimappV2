package com.example.animapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.animapp.Activities.profil;
import com.example.animapp.Fragments.AnimListFragment;
import com.example.animapp.Fragments.GalerieFragment;
import com.example.animapp.Fragments.PostFragment;
import com.example.animapp.Fragments.ProfilFragment;
import com.example.animapp.animapp.R;

import java.util.ArrayList;
import java.util.List;

import eu.long1.spacetablayout.SpaceTabLayout;

public class MainFragmentActivity extends AppCompatActivity {
    SpaceTabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_fragment);

        //BottomNavigationView bottomNavigationView = findViewById(R.id.BottomNav);
       // bottomNavigationView.setOnNavigationItemSelectedListener(navListener);
        tabLayout = (SpaceTabLayout) findViewById(R.id.spaceTabLayout);

        List<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(new ProfilFragment());
        fragmentList.add(new GalerieFragment());
        fragmentList.add(new AnimListFragment());
        fragmentList.add(new PostFragment());

        ViewPager viewPager = findViewById(R.id.viewPager);
        tabLayout.initialize(viewPager, getSupportFragmentManager(),
                fragmentList, savedInstanceState);
        tabLayout.setTabFourIcon(R.drawable.ic_tent2);

        //afficher PostActivity comme première activité dans le fragment
        /*if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment,
                    new PostFragment()).commit();
        }*/

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        tabLayout.saveState(outState);
        super.onSaveInstanceState(outState);
    }


    /*
    Gère la navigation entre les bouton du BottomNavigation
     */
   /* private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    if(menuItem.getItemId() == R.id.action_profil){
                        startActivity(new Intent(getApplicationContext(), profil.class));
                    }else{
                        Fragment fragment = null;
                        switch (menuItem.getItemId()) {
                            case R.id.action_photo:
                                fragment = new GalerieFragment();
                                break;
                            case R.id.action_list:
                                fragment = new AnimListFragment();
                                break;

                            case R.id.action_menu:
                                fragment = new PostFragment();
                                break;
                        }
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.fragment, fragment).commit();
                    }

                    return true;
                }
            };*/
}
